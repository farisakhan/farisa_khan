import { NavLink } from "react-router-dom";

const Sidebar = () => {
  const linkStyle = {
    color: "#ecf0f1",
    textDecoration: "none",
    display: "block",
    padding: "0.5rem 0",
    borderRadius: "4px"
  };

  const activeStyle = {
    background: "#34495e",
    fontWeight: "bold"
  };

  return (
    <div style={{
      width: "220px",
      background: "#2c3e50",
      padding: "1rem",
      color: "#fff",
      height: "100vh"
    }}>
      <h2 style={{ color: "#f1c40f", marginBottom: "2rem" }}>🍽️ Restro Admin</h2>
      <nav>
        <ul style={{ listStyle: "none", padding: 0 }}>
          <li>
            <NavLink to="/dashboard" style={({ isActive }) => ({ ...linkStyle, ...(isActive ? activeStyle : {}) })}>
              Dashboard
            </NavLink>
          </li>
          <li>
            <NavLink to="/employees" style={({ isActive }) => ({ ...linkStyle, ...(isActive ? activeStyle : {}) })}>
              Employees
            </NavLink>
          </li>
          <li>
            <NavLink to="/tables" style={({ isActive }) => ({ ...linkStyle, ...(isActive ? activeStyle : {}) })}>
              Tables
            </NavLink>
          </li>
          <li>
            <NavLink to="/menu" style={({ isActive }) => ({ ...linkStyle, ...(isActive ? activeStyle : {}) })}>
              Food Menu
            </NavLink>
          </li>
          <li>
            <NavLink to="/orders" style={({ isActive }) => ({ ...linkStyle, ...(isActive ? activeStyle : {}) })}>
              Orders
            </NavLink>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
