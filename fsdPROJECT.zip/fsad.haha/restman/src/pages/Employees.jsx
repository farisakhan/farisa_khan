const Employees = () => {
    return (
      <div>
        <h1 style={{ color: "#228B22" }}>Employees</h1>
        <p>Meet the amazing people behind your meals and service.</p>
        <ul>
          <li>👨‍🍳 John – Head Chef</li>
          <li>👩‍🍳 Priya – Sous Chef</li>
          <li>👩‍🍳 Ayesha – Line Chef</li>
          <li>👨‍🍳 Daniel – Pastry Chef</li>
          <li>🧑‍💼 Rahul – Restaurant Manager</li>
          <li>👨‍💼 Neha – Assistant Manager</li>
          <li>👨‍🍽️ Alok – Waiter (Tables 1 & 2)</li>
          <li>👩‍🍽️ Sneha – Waitress (Tables 3 & 4)</li>
          <li>👨‍🍽️ Arjun – Waiter (Tables 5 & 6)</li>
          <li>👩‍🍽️ Meera – Waitress (Tables 7 & 8)</li>
          <li>👨‍🍽️ Kabir – Waiter (Tables 9 & 10)</li>
        </ul>
      </div>
    );
  };
  
  export default Employees;
  