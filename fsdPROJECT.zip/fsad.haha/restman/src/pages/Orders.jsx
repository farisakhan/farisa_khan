import { useState } from "react";

const menuItems = [
  // Starters
  { name: "🥗 Greek Salad", price: 199 },
  { name: "🍞 Garlic Bread", price: 129 },
  { name: "🌽 Corn Cheese Balls", price: 179 },
  { name: "🍟 French Fries", price: 149 },
  { name: "🥣 Tomato Soup", price: 119 },
  // Main Course
  { name: "🍕 Margherita Pizza", price: 299 },
  { name: "🍕 Farmhouse Pizza", price: 349 },
  { name: "🍔 Veg Burger", price: 149 },
  { name: "🍔 Double Cheese Burger", price: 199 },
  { name: "🍝 Pasta Alfredo", price: 249 },
  { name: "🍝 Pasta Arrabiata", price: 259 },
  { name: "🥘 Paneer Butter Masala", price: 229 },
  // Beverages
  { name: "🥤 Lemon Mojito", price: 99 },
  { name: "🧋 Cold Coffee", price: 129 },
  { name: "🍹 Orange Juice", price: 109 },
  { name: "🧃 Apple Juice", price: 109 },
  { name: "☕ Hot Coffee", price: 89 },
  { name: "🧊 Iced Tea", price: 99 },
  // Desserts
  { name: "🍨 Vanilla Ice Cream", price: 89 },
  { name: "🍫 Chocolate Brownie", price: 149 },
  { name: "🍮 Caramel Custard", price: 119 },
  { name: "🍰 Cheesecake", price: 179 },
  { name: "🍩 Donuts", price: 99 },
];

const initialTables = [
  { number: "Table 1", occupied: false },
  { number: "Table 2", occupied: true },
  { number: "Table 3", occupied: false },
  { number: "Table 4", occupied: false },
  { number: "Table 5", occupied: false },
  { number: "Table 6", occupied: true },
  { number: "Table 7", occupied: false },
  { number: "Table 8", occupied: false },
];

const Orders = () => {
  const [selectedItem, setSelectedItem] = useState("");
  const [orderItems, setOrderItems] = useState([]);
  const [orderType, setOrderType] = useState("Dine-in");
  const [tables, setTables] = useState(initialTables);
  const [tableNo, setTableNo] = useState("");
  const [step, setStep] = useState("ordering");
  const [paymentMethod, setPaymentMethod] = useState("");

  const addItemToOrder = () => {
    const item = menuItems.find((item) => item.name === selectedItem);
    if (item) {
      setOrderItems([...orderItems, item]);
      setSelectedItem("");
    }
  };

  const removeItem = (index) => {
    const updatedItems = [...orderItems];
    updatedItems.splice(index, 1);
    setOrderItems(updatedItems);
  };

  const total = orderItems.reduce((sum, item) => sum + item.price, 0);
  const prepTime = orderItems.length * 5;

  const placeOrder = () => {
    if (orderItems.length === 0) {
      alert("Please add items to your order.");
      return;
    }
    if (orderType === "Dine-in") {
      if (!tableNo) {
        alert("Please select a table number.");
        return;
      }

      const selected = tables.find((t) => t.number === tableNo);
      if (selected?.occupied) {
        alert("Selected table is already occupied.");
        return;
      }

      setTables((prev) =>
        prev.map((t) =>
          t.number === tableNo ? { ...t, occupied: true } : t
        )
      );
    }

    setStep("payment");
  };

  const handlePayment = () => {
    if (!paymentMethod) {
      alert("Please select a payment method.");
      return;
    }
    setStep("success");
  };

  return (
    <div style={{ padding: "1rem" }}>
      <h1 style={{ color: "#4169E1" }}>Place Your Order</h1>

      {step === "ordering" && (
        <>
          <div>
            <select
              value={selectedItem}
              onChange={(e) => setSelectedItem(e.target.value)}
            >
              <option value="">Select Menu Item</option>

              <optgroup label="🍽️ Starters">
                {menuItems.slice(0, 5).map((item) => (
                  <option key={item.name} value={item.name}>
                    {item.name} – ₹{item.price}
                  </option>
                ))}
              </optgroup>

              <optgroup label="🍕 Main Course">
                {menuItems.slice(5, 12).map((item) => (
                  <option key={item.name} value={item.name}>
                    {item.name} – ₹{item.price}
                  </option>
                ))}
              </optgroup>

              <optgroup label="🍹 Beverages">
                {menuItems.slice(12, 18).map((item) => (
                  <option key={item.name} value={item.name}>
                    {item.name} – ₹{item.price}
                  </option>
                ))}
              </optgroup>

              <optgroup label="🍰 Desserts">
                {menuItems.slice(18).map((item) => (
                  <option key={item.name} value={item.name}>
                    {item.name} – ₹{item.price}
                  </option>
                ))}
              </optgroup>
            </select>

            <button onClick={addItemToOrder} style={{ marginLeft: "1rem" }}>
              Add Item
            </button>
          </div>

          <div style={{ marginTop: "1rem" }}>
            <label>
              Order Type:
              <select
                value={orderType}
                onChange={(e) => {
                  setOrderType(e.target.value);
                  setTableNo("");
                }}
                style={{ marginLeft: "0.5rem" }}
              >
                <option>Dine-in</option>
                <option>Takeout</option>
                <option>Delivery</option>
              </select>
            </label>
          </div>

          {orderType === "Dine-in" && (
            <div style={{ marginTop: "1rem" }}>
              <label>
                Select Table Number:
                <select
                  value={tableNo}
                  onChange={(e) => setTableNo(e.target.value)}
                  style={{ marginLeft: "0.5rem" }}
                >
                  <option value="">Select</option>
                  {tables.map((table) =>
                    table.occupied ? null : (
                      <option key={table.number} value={table.number}>
                        {table.number}
                      </option>
                    )
                  )}
                </select>
              </label>
            </div>
          )}

          {orderItems.length > 0 && (
            <div style={{ marginTop: "2rem" }}>
              <h3>Your Items:</h3>
              <ul>
                {orderItems.map((item, index) => (
                  <li key={index}>
                    {item.name} – ₹{item.price}{" "}
                    <button onClick={() => removeItem(index)}>Remove</button>
                  </li>
                ))}
              </ul>
              <p><strong>Total:</strong> ₹{total}</p>
              <p><strong>Estimated Prep Time:</strong> {prepTime} mins</p>

              <button
                onClick={placeOrder}
                style={{
                  backgroundColor: "#28a745",
                  color: "white",
                  padding: "0.5rem 1rem",
                  marginTop: "1rem",
                }}
              >
                Proceed to Payment
              </button>
            </div>
          )}
        </>
      )}

      {step === "payment" && (
        <div style={{ marginTop: "2rem" }}>
          <h2>Choose Payment Method</h2>
          <label>
            <input
              type="radio"
              name="payment"
              value="UPI"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />{" "}
            UPI
          </label>
          <br />
          <label>
            <input
              type="radio"
              name="payment"
              value="Card"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />{" "}
            Debit/Credit Card
          </label>
          <br />
          <label>
            <input
              type="radio"
              name="payment"
              value="Cash"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />{" "}
            Cash on Delivery
          </label>
          <br />
          <button
            onClick={handlePayment}
            style={{
              backgroundColor: "#007bff",
              color: "white",
              padding: "0.5rem 1rem",
              marginTop: "1rem",
            }}
          >
            Pay ₹{total}
          </button>
        </div>
      )}

      {step === "success" && (
        <div style={{ marginTop: "2rem" }}>
          <h2>🎉 Payment Successful!</h2>
          <p><strong>Order Type:</strong> {orderType}</p>
          {orderType === "Dine-in" && <p><strong>Table No:</strong> {tableNo}</p>}
          <p><strong>Payment:</strong> {paymentMethod}</p>
          <p><strong>Total:</strong> ₹{total}</p>
          <p><strong>Prep Time:</strong> {prepTime} mins</p>
          <p>Your order has been placed successfully. Thank you!</p>
        </div>
      )}
    </div>
  );
};

export default Orders;
