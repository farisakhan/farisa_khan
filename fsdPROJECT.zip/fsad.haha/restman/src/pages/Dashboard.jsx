import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Add any additional logout logic here (e.g., clear session, remove token)
    console.log("Logging out...");
    navigate("/login"); // Redirect to login page
  };

  return (
    <div>
      <h1 style={{ color: "#4B0082" }}>Welcome to the Restro</h1>
      <p>Monitor our restaurant’s operations at a glance.</p>
      <ul>
        <li>👥 13 Employees</li>
        <li>🪑 10 Tables</li>
        <li>📋 12 Menu Items</li>
        <li>🛒 26 New Orders Today</li>
      </ul>
      <button 
        onClick={handleLogout} 
        style={{ 
          backgroundColor: "#4B0082", 
          color: "white", 
          padding: "10px 20px", 
          border: "none", 
          borderRadius: "5px", 
          cursor: "pointer"
        }}
      >
        Logout
      </button>
    </div>
  );
};

export default Dashboard;
