import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Settings = ({ clearOrderHistory }) => {
  const [theme, setTheme] = useState("light");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    navigate("/login");
  };

  const handleResetHistory = () => {
    clearOrderHistory();
    alert("Order history has been reset.");
  };

  return (
    <div style={{ padding: "1rem" }}>
      <h1 style={{ color: "#4169E1" }}>⚙️ Settings</h1>

      <div style={{ marginTop: "1rem" }}>
        <label>
          Theme:
          <select
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
            style={{ marginLeft: "0.5rem" }}
          >
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </label>
      </div>

      <div style={{ marginTop: "1rem" }}>
        <label>
          <input
            type="checkbox"
            checked={notificationsEnabled}
            onChange={(e) => setNotificationsEnabled(e.target.checked)}
          />
          Enable Notifications
        </label>
      </div>

      <div style={{ marginTop: "1.5rem" }}>
        <button
          onClick={handleResetHistory}
          style={{
            backgroundColor: "#ffc107",
            color: "black",
            padding: "0.5rem 1rem",
            marginRight: "1rem",
          }}
        >
          Reset Order History
        </button>

        <button
          onClick={handleLogout}
          style={{
            backgroundColor: "#dc3545",
            color: "white",
            padding: "0.5rem 1rem",
          }}
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Settings;
