import { useEffect, useRef, useState } from "react";

const Tables = () => {
  const [tables, setTables] = useState(
    Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      status: Math.random() < 0.5 ? "Available" : "Occupied",
      remainingTime: 0,
    }))
  );

  const intervalRef = useRef(null);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setTables((prevTables) =>
        prevTables.map((table) => {
          if (table.status === "Reserved" && table.remainingTime > 0) {
            return { ...table, remainingTime: table.remainingTime - 1 };
          } else if (table.status === "Reserved" && table.remainingTime === 0) {
            return { ...table, status: "Occupied" };
          }
          return table;
        })
      );
    }, 1000);

    return () => clearInterval(intervalRef.current);
  }, []);

  const handleBook = (id) => {
    setTables((prev) =>
      prev.map((table) =>
        table.id === id
          ? { ...table, status: "Reserved", remainingTime: 120 }
          : table
      )
    );
    alert(`✅ Table ${id} booked successfully!`);
  };

  const handleCancel = (id) => {
    setTables((prev) =>
      prev.map((table) =>
        table.id === id
          ? { ...table, status: "Available", remainingTime: 0 }
          : table
      )
    );
    alert(`❌ Reservation for Table ${id} cancelled.`);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0");
    const secs = (seconds % 60).toString().padStart(2, "0");
    return `${mins}:${secs}`;
  };

  return (
    <div>
      <h1 style={{ color: "#FF8C00" }}>Book a Table</h1>
      <p>Reserve a table. You can cancel within 2 minutes.</p>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
        {tables.map((table) => (
          <div
            key={table.id}
            style={{
              border: "1px solid #ccc",
              padding: "1rem",
              borderRadius: "8px",
              width: "200px",
              backgroundColor:
                table.status === "Available"
                  ? "#e6ffe6"
                  : table.status === "Reserved"
                  ? "#fff8e1"
                  : "#ffe6e6",
            }}
          >
            <h3>🪑 Table {table.id}</h3>
            <p
              style={{
                color:
                  table.status === "Available"
                    ? "#32CD32"
                    : table.status === "Reserved"
                    ? "#FFA500"
                    : "#DC143C",
              }}
            >
              {table.status}
            </p>

            {table.status === "Available" && (
              <button onClick={() => handleBook(table.id)}>Book</button>
            )}

            {table.status === "Reserved" && (
              <>
                <p>⏳ Cancel in: {formatTime(table.remainingTime)}</p>
                <button onClick={() => handleCancel(table.id)}>Cancel</button>
              </>
            )}

            {table.status === "Occupied" && (
              <button disabled style={{ opacity: 0.6 }}>
                Not Available
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Tables;
