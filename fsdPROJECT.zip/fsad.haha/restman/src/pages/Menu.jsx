const Menu = () => {
    return (
      <div>
        <h1 style={{ color: "#8B0000" }}>Our Menu</h1>
  
        <h2>🍽️ Starters</h2>
        <ul>
          <li>🥗 Greek Salad – ₹199</li>
          <li>🍞 Garlic Bread – ₹129</li>
          <li>🌽 Corn Cheese Balls – ₹179</li>
          <li>🍟 French Fries – ₹149</li>
          <li>🥣 Tomato Soup – ₹119</li>
        </ul>
  
        <h2>🍕 Main Course</h2>
        <ul>
          <li>🍕 Margherita Pizza – ₹299</li>
          <li>🍕 Farmhouse Pizza – ₹349</li>
          <li>🍔 Veg Burger – ₹149</li>
          <li>🍔 Double Cheese Burger – ₹199</li>
          <li>🍝 Pasta Alfredo – ₹249</li>
          <li>🍝 Pasta Arrabiata – ₹259</li>
          <li>🥘 Paneer Butter Masala – ₹229</li>
        </ul>
  
        <h2>🍹 Beverages</h2>
        <ul>
          <li>🥤 Lemon Mojito – ₹99</li>
          <li>🧋 Cold Coffee – ₹129</li>
          <li>🍹 Orange Juice – ₹109</li>
          <li>🧃 Apple Juice – ₹109</li>
          <li>☕ Hot Coffee – ₹89</li>
          <li>🧊 Iced Tea – ₹99</li>
        </ul>
  
        <h2>🍰 Desserts</h2>
        <ul>
          <li>🍨 Vanilla Ice Cream – ₹89</li>
          <li>🍫 Chocolate Brownie – ₹149</li>
          <li>🍮 Caramel Custard – ₹119</li>
          <li>🍰 Cheesecake – ₹179</li>
          <li>🍩 Donuts – ₹99</li>
        </ul>
      </div>
    );
  };
  
  export default Menu;
  