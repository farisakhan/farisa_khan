import Sidebar from "../components/Sidebar";

const DashboardLayout = ({ children }) => {
  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <Sidebar />
      <div style={{ padding: "1rem", flex: 1 }}>
        {children}
      </div>
    </div>
  );
};

export default DashboardLayout;
